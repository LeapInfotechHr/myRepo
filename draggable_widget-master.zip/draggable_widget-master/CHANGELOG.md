## [1.1.1] - Updated documentation.

## [1.1.0] - Updated documentation.

- Added `center` anchoring position, thanks to @dreampowder

## [1.0.1] - Updated documentation.

## [1.0.0] - First release.

- Added basic functionality.
- Added example app
